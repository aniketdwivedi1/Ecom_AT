package com.practice_programs;

public class Square extends Shape {
	private double side;

	public Square(double side) {
		this.side = side;
		
	}

	@Override
	public void displayArea() {
		double area = side * side;
		System.out.println("Area of square: " + area);
	}
}