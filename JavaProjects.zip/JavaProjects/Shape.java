package com.practice_programs;

public class Shape {

	public void displayArea() {
		// This method can be customized or left abstract for subclasses to implement
		System.out.println("Area calculation not implemented.");
	}
}
