package com.practice_programs;

import java.util.ArrayList;


public class Main {
	public static void main(String[] args) {
		
		ArrayList<Shape> shapes = new ArrayList<>();

		// Creating objects for Circle, Square and Rectangle
		Shape square = new Square(4.5);
		Circle circle = new Circle(8);
		Rectangle rectangle = new Rectangle(4.5, 8);

		// Adding objects to the ArrayList
		shapes.add(circle);
		shapes.add(square);
		shapes.add(rectangle);

		// Displaying calculated areas using loop
		for (Shape shape : shapes) {
			try {
				shape.displayArea();
			} catch (Exception e) {
				System.out.println("Error calculating area: " + e.getMessage());
			} finally {
				// Any final action can be performed here
			}
		}
	}
}
