package com.seleniumtest.exwebelement;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CustomBrowserPopupTest {

	static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {

		setUp();

		// test alert
		testCustomPopup();

	}

	public static void setUp() {

		// step1: formulate a test domain url & driver path
		String siteUrl = "https://www.amazon.in/";
		String driverPath = "Drivers/chromedriver.exe";

		// step2: set system properties for selenium dirver
		System.setProperty("webdriver.chrome.driver", driverPath);

		// step3: instantiate selenium webdriver
		WebDriver driver = new ChromeDriver();

		// step4: add implicit wait (Unconditional Delay)
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));

		// step5: launch browser
		driver.get(siteUrl);
	}

	public static void testCustomPopup() throws InterruptedException {
		// find location popup and click
		driver.findElement(By.id("nav-global-location-popover-link")).click();

		Thread.sleep(3000);

		// find current window
		String mainWindow = driver.getWindowHandle();

		// list of external popups
		Set<String> windows = driver.getWindowHandles();

		for (String childWindow : windows) {
			// Switch to child window
			driver.switchTo().window(childWindow);

			driver.findElement(By.id("GLUXZipUpdateInput")).sendKeys("500001");

			driver.findElement(By.cssSelector("#GLUXZipUpdate > span:nth-child(1) > input:nth-child(1)")).click();

		}

		driver.switchTo().window(mainWindow);
		Thread.sleep(3000);

	}
}
